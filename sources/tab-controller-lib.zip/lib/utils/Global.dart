

class Global {
  static double statusBarHeight = 0.0;
  static double appBarHeight    = 0.0;
}