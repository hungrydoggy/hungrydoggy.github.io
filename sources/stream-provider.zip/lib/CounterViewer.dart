import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class CounterViewer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<int>(
      builder: (context, value, child) {
        return Text('${value}', style: TextStyle(fontSize: 30));
      },
    );
  }

}