import 'package:flutter/material.dart';
import 'package:my_eshop/utils/Global.dart';
import 'package:my_eshop/widgets/Cart.dart';
import 'package:my_eshop/widgets/Profile.dart';

import 'ItemList.dart';


class MainWidget extends StatefulWidget {
  @override
  _MainWidgetState createState() => _MainWidgetState();
}

class _MainWidgetState extends State<MainWidget> with SingleTickerProviderStateMixin {
  TabController _tabController;

  @override
  void initState() {
    super.initState();

    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    super.dispose();

    _tabController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final appBar = AppBar(
      automaticallyImplyLeading: false,
      flexibleSpace: SafeArea(
        child: TabBar(
          controller: _tabController,
          tabs: [
            Tab(
              icon: Icon(Icons.shopping_basket),
              text: 'Item List',
            ),
            Tab(
              icon: Icon(Icons.shopping_cart),
              text: 'Cart',
            ),
            Tab(
              icon: Icon(Icons.person),
              text: 'Profile',
            ),
          ],
        ),
      ),
    );
    Global.statusBarHeight = mq.padding.top;
    Global.appBarHeight = appBar.preferredSize.height;


    return Scaffold(
      appBar: appBar,

      body: SafeArea(
        child: TabBarView(
          controller: _tabController,
          children: <Widget>[
            ItemList(
              onAddToCart: () {
                _tabController.animateTo(1);
              },
            ),
            Cart(),
            Profile(),
          ],
        ),
      ),

    );
  }

}
