import 'package:flutter/material.dart';


class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: ListView(
        shrinkWrap: true,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              ClipOval(
                child: SizedBox(
                  width : 120,
                  height: 120,
                  child: Image(
                    image: NetworkImage(
                      "https://pbs.twimg.com/profile_images/1603440593/AgDLph81_400x400"),
                  ),
                ),
              ),

              Container(height: 10.0),
              Text(
                '쇼핑왕 보거스',
                style: TextStyle(fontSize: 20.0),
              ),
              Text(
                'VIP customer',
                style: TextStyle(color: Colors.blue),
              ),

              Container(height: 50.0,),
              FractionallySizedBox(
                widthFactor: 0.62,
                child: Column(
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(right: 20.0),
                          child: Icon(Icons.phone, color: Colors.black54,),
                        ),
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: 'Please enter phone numbers',
                            ),
                          ),
                        ),
                      ],
                    ),

                    Row(
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(right: 20.0),
                          child: Icon(Icons.email, color: Colors.black54,),
                        ),
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: 'Please enter an e-mail',
                            ),
                          ),
                        ),
                      ],
                    ),

                    Row(
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(right: 20.0),
                          child: Icon(Icons.flag, color: Colors.black54,),
                        ),
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: 'Please enter an address',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

            ],
          ),
        ],
      ),
    );
  }
}