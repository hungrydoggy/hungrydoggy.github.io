import 'package:my_eshop/utils/ServerApi.dart';


class Global {
  static double statusBarHeight = 0.0;
  static double appBarHeight    = 0.0;
  static String server_address = 'http://1.234.4.139:3300';

  static String token       = '';
  static int    customer_id =  0;

  static List<ItemResponse           > items               = [];
  static List<CustomerHasItemResponse> oldCustomerHasItems = [];
}