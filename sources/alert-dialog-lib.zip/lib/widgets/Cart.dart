import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:my_eshop/utils/Global.dart';
import 'package:my_eshop/utils/ServerApi.dart';
import 'package:my_eshop/utils/StringUtil.dart';
import 'package:my_eshop/widgets/ItemDetail.dart';
import 'package:my_eshop/widgets/LoadingWrapper.dart';


class Cart extends StatefulWidget {
  @override
  _CartState createState() => _CartState();
}

class _CartState extends State<Cart> {

  final _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _isLoading = false;
  List<_ItemInfo> _itemInfos;
  final _itemidControllerMap = Map<int, TextEditingController>();


  @override
  void initState() {
    super.initState();

    _itemInfos = _makeItemInfos(Global.oldCustomerHasItems);
    _refreshItemidControllerMap(_itemInfos);
    _fetchDataAndRefresh();
  }

  @override
  void dispose() {
    super.dispose();

    for (final controller in _itemidControllerMap.values)
      controller.dispose();
    _itemidControllerMap.clear();
  }

  @override
  Widget build(BuildContext context) {

    // make widgets
    final widgets = <Widget>[];
    for (final ii in _itemInfos) {
      widgets.add(
          Row(
            children: <Widget>[
              Checkbox(
                value: ii.isChecked,
                onChanged: (v)=>setState(()=>ii.isChecked=v),
              ),
              Expanded(
                flex: 3,
                child: FlatButton(
                  child: Container(
                    height: 150.0,
                    margin: EdgeInsets.only(right: 20.0),
                    child: ii.image,
                  ),
                  onPressed: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context)=> ItemDetail(itemId: ii.item_id,)),
                    );
                  },
                ),
              ),
              Flexible(
                flex: 5,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      ii.title,
                      style: TextStyle(fontSize: 18.0),
                    ),
                    Text(
                      '${StringUtil.makeCommaedString(ii.price)}원',
                      style: TextStyle(fontSize: 15.0, color: Colors.orange),
                    ),
                    Row(
                      children: <Widget>[
                        Text('개수'),
                        Expanded(child: SizedBox()),
                        Container(
                          width : 25,
                          height: 25,
                          margin: EdgeInsets.only(left: 10, right: 10),
                          child: FlatButton(
                            padding: EdgeInsets.all(0),
                            child: Icon(Icons.add, size: 20),
                            onPressed: () {
                              final ctr = _itemidControllerMap[ii.id];
                              final count = (ctr.text == '')? 0: int.parse(ctr.text);
                              ctr.text = '${min(999, count + 1)}';
                            },
                          ),
                        ),
                        SizedBox(
                          width: 40.0,
                          child: TextField(
                            controller: _itemidControllerMap[ii.id],
                            keyboardType: TextInputType.numberWithOptions(),
                            inputFormatters: [
                              WhitelistingTextInputFormatter.digitsOnly,
                              LengthLimitingTextInputFormatter(3),
                            ],
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              contentPadding: EdgeInsets.all(1),
                            ),
                          ),
                        ),
                        Container(
                          width : 25,
                          height: 25,
                          margin: EdgeInsets.only(left: 10, right: 10),
                          child: FlatButton(
                            padding: EdgeInsets.all(0),
                            child: Icon(Icons.remove, size: 20),
                            onPressed: () {
                              final ctr = _itemidControllerMap[ii.id];
                              final count = (ctr.text == '')? 0: int.parse(ctr.text);
                              ctr.text = '${max(0, count - 1)}';
                            },
                          ),
                        ),
                        SizedBox(width: 5),
                      ],
                    ),

                    Row(
                      children: <Widget>[
                        Text('금액'),
                        Expanded(child: SizedBox()),
                        Text('${StringUtil.makeCommaedString(ii.price*ii.count)}원', style: TextStyle(fontSize: 18, color: Colors.green),),
                        SizedBox(width: 15),
                      ],
                    ),

                  ],
                ),
              ),
            ],
          )
      );
    }


    return Scaffold(
      key: _scaffoldKey,
      body: LoadingWrapper(
        isLoading: _isLoading,
        child: Column(
          children: <Widget>[
            Expanded(
              child: ListView(
                children: widgets,
              ),
            ),

            Container(
              height: 10,
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(color: Colors.black54),
                ),
              ),
            ),

            Container(
              margin: EdgeInsets.only(left: 30, right: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text('총 가격:', style: TextStyle(fontSize: 18),),
                  SizedBox(width: 18),
                  Text(
                    '${StringUtil.makeCommaedString(_itemInfos.where((ii)=>ii.isChecked).map((ii)=>ii.price*ii.count).fold(0, (a, b)=>a+b))} 원',
                    style: TextStyle(fontSize: 20, color: Colors.orange),
                  ),
                ],
              ),
            ),

            SizedBox(height: 5),

            Container(
              width: double.infinity,
              margin: EdgeInsets.only(left: 30, right: 30),
              child: FlatButton(
                color: Colors.blue,
                textColor: Colors.white,
                child: Text('구매하기', style: TextStyle(fontSize: 16)),
                onPressed: () async {

                  // 아래 코드를 로딩 띄우기 전으로 옮김
                  final checkedIds = <int>[];
                  for (final ii in _itemInfos) {
                    if (ii.isChecked == false)
                      continue;

                    final countText = _itemidControllerMap[ii.id].text;
                    await ServerApi.updateCustomerHasItem(
                      ii.id,
                      (countText == '')? 0: int.parse(countText),
                    );

                    checkedIds.add(ii.id);
                  }

                  // 체크된 아이템이 있는지 확인을 로딩 띄우기 전으로 옮김
                  if (checkedIds.length <= 0)
                    return;

                  // 다이얼 로그를 띄워서 구매진행 여부 묻기
                  bool isOk = await showDialog(
                      context: context,
                    barrierDismissible: true,
                    builder: (context) {
                      return AlertDialog(
                        title: Text('구매 진행'),
                        content: Text('구매를 진행하시겠습니까?'),
                        actions: <Widget>[
                          FlatButton(
                            child: Text('예'),
                            onPressed: () {
                              Navigator.pop(context, true);
                            },
                          ),
                          FlatButton(
                            child: Text('아니오'),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                          ),
                        ],
                      );
                    },
                  );
                  if (isOk != true)
                    return;


                  setState(() { _isLoading = true; });

                  try {
                    await ServerApi.payCustomerHasItems(Global.customer_id, checkedIds);
                    await _fetchDataAndRefresh();

                    // 테스트 용. 현재까지 구매완료된 내역 보여주기
                    final paidList = await ServerApi.fetchCustomerHasItem({
                      'where': {
                        'status': 'PAID',
                      },
                      'include': ['item'],
                    });
                    for (final paid in paidList) {
                      print('${paid.paid_dtm} : ${paid.item.title} ${paid.count}개');
                    }

                    _scaffoldKey.currentState.showSnackBar(
                      SnackBar(content: Text('구매처리가 완료 되었습니다')),
                    );

                    setState(() { _isLoading = false; });

                  }on ServerApiException catch (e) {
                    _scaffoldKey.currentState.showSnackBar(
                      SnackBar(content: Text(json.decode(e.response.body)['message'])),
                    );
                    setState(() { _isLoading = false; });

                  }catch (e) {
                    _scaffoldKey.currentState.showSnackBar(
                      SnackBar(content: Text(json.decode(e.toString()))),
                    );
                    setState(() { _isLoading = false; });
                  }

                },
              ),
            ),

            SizedBox(height: 10,),

          ],
        ),
      ),
    );
  }

  Future<void> _fetchDataAndRefresh () async {
    try {
      setState(() {
        _isLoading = true;
      });

      final customerHasItems = await ServerApi.fetchCustomerHasItem({
        'where': {
          'status': 'CART',
        },
        'include': [
          { 'association': 'item', },
        ],
      });
      await Future.delayed(Duration(seconds: 1));
      Global.oldCustomerHasItems = customerHasItems;

      if (mounted == false)
        return;

      final newItemInfos = _makeItemInfos(customerHasItems);

      setState(() {
        _refreshItemidControllerMap(newItemInfos);
        _isLoading = false;
        _itemInfos = newItemInfos;
      });

    }on ServerApiException catch (e) {
      final msg = json.decode(e.response.body)['message'];
      print(msg);
      setState(() {
        _isLoading = false;
      });

    }catch (e) {
      print(e.toString());
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _refreshItemidControllerMap (List<_ItemInfo> itemInfos) {
    // create controllers
    for (final ii in itemInfos) {
      if (_itemidControllerMap.containsKey(ii.id) == true) {
        _itemidControllerMap[ii.id].text = '${ii.count}';
        continue;
      }

      final ctr = TextEditingController(text: '${ii.count}');
      ctr.addListener(() {
        setState(() {
          // ii.count를 바꾸지 않고, _itemInfos에서 id로 찾아서 바꿔야 한다.
          // 호출 시점에 _itemInfos가 수정됐을 가능성이 높다.
          _itemInfos.firstWhere((info)=>info.id==ii.id).count = (ctr.text == '')? 0: int.parse(ctr.text);
        });
      });
      _itemidControllerMap[ii.id] = ctr;
    }
  }

  List<_ItemInfo> _makeItemInfos (List<CustomerHasItemResponse> customerHasItems) {
    final newItemInfos = <_ItemInfo>[];
    for (final chi in customerHasItems) {
      newItemInfos.add(
        _ItemInfo(
          chi.id,
          chi.item_id,
          Image.network(chi.item.image),
          chi.item.title,
          chi.item.price,
          chi.count,
        ),
      );
    }

    return newItemInfos;
  }

}


class _ItemInfo {
  int    id;
  int    item_id;
  Image  image;
  String title;
  int    price;
  int    count;
  bool   isChecked = true;

  _ItemInfo(this.id, this.item_id, this.image, this.title, this.price, this.count);
}