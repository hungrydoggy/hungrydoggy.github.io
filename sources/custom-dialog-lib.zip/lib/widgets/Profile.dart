import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:my_eshop/utils/Global.dart';
import 'package:my_eshop/utils/ServerApi.dart';
import 'package:my_eshop/widgets/LoadingWrapper.dart';


class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  bool _isLoading = false;
  _ProfileInfo _profileInfo = _ProfileInfo('', '', '', '');

  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey     = GlobalKey<FormState>();

  final _phoneNumberCtr = TextEditingController();
  final _emailCtr       = TextEditingController();
  final _addressCtr     = TextEditingController();


  @override
  void initState() {
    super.initState();

    if (Global.customer != null) {
      _profileInfo = _ProfileInfo(
        Global.customer.name,
        Global.customer.phone_number,
        Global.customer.email,
        Global.customer.address,
      );
      _phoneNumberCtr.text = _profileInfo.phoneNumber;
      _emailCtr      .text = _profileInfo.email      ;
      _addressCtr    .text = _profileInfo.address    ;
    }else {
      _fetchDataAndRefresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);

    return Scaffold(
      key: _scaffoldKey,
      body: LoadingWrapper(
        isLoading: _isLoading,
        child: SingleChildScrollView(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: mq.size.height - Global.statusBarHeight - Global.appBarHeight,
            ),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  ClipOval(
                    child: SizedBox(
                      width : 120,
                      height: 120,
                      child: Image(
                        image: NetworkImage(
                          "https://pbs.twimg.com/profile_images/1603440593/AgDLph81_400x400"),
                      ),
                    ),
                  ),

                  Container(height: 10.0),
                  Text(
                    _profileInfo.name,
                    style: TextStyle(fontSize: 20.0),
                  ),
                  Text(
                    'VIP customer',
                    style: TextStyle(color: Colors.blue),
                  ),

                  Container(height: 50.0,),
                  FractionallySizedBox(
                    widthFactor: 0.62,
                    child: Column(
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.only(right: 20.0),
                              child: Icon(Icons.phone, color: Colors.black54,),
                            ),
                            Expanded(
                              child: TextFormField(
                                controller: _phoneNumberCtr,
                                decoration: InputDecoration(
                                  hintText: 'Please enter phone numbers',
                                ),
                              ),
                            ),
                          ],
                        ),

                        Row(
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.only(right: 20.0),
                              child: Icon(Icons.email, color: Colors.black54,),
                            ),
                            Expanded(
                              child: TextFormField(
                                controller: _emailCtr,
                                decoration: InputDecoration(
                                  hintText: 'Please enter an e-mail',
                                ),
                                validator: (v)=>(v.isEmpty)? '내용을 입력해 주세요': (v.indexOf('@') < 0)? '올바른 이메일 형식이 아닙니다': null,
                              ),
                            ),
                          ],
                        ),

                        Row(
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.only(right: 20.0),
                              child: Icon(Icons.flag, color: Colors.black54,),
                            ),
                            Expanded(
                              child: TextFormField(
                                controller: _addressCtr,
                                decoration: InputDecoration(
                                  hintText: 'Please enter an address',
                                ),
                                validator: (v)=>(v.isEmpty)? '내용을 입력해 주세요': null,
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 30),

                        FlatButton(
                          color: Colors.blue,
                          textColor: Colors.white,
                          child: Text('수정'),
                          onPressed: () async {
                            if (_formKey.currentState.validate() == false)
                              return;

                            try {
                              setState(() {
                                _isLoading = true;
                              });

                              await ServerApi.updateCustomer(
                                  Global.customer_id,
                                  {
                                    'phone_number': _phoneNumberCtr.text,
                                    'email': _emailCtr.text,
                                    'address': _addressCtr.text,
                                  }
                              );
                              await Future.delayed(Duration(seconds: 1));
                              Global.customer = null;

                              if (mounted == false)
                                return;

                              setState(() {
                                _isLoading = false;
                              });
                            }on ServerApiException catch (e) {
                              final msg = json.decode(e.response.body)['message'];
                              _scaffoldKey.currentState.showSnackBar(
                                SnackBar(content: Text(msg)),
                              );
                              setState(() {
                                _isLoading = false;
                              });

                            }catch (e) {
                              _scaffoldKey.currentState.showSnackBar(
                                SnackBar(content: Text(e.toString())),
                              );
                              setState(() {
                                _isLoading = false;
                              });
                            }

                          },
                        ),

                      ],
                    ),
                  ),

                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _fetchDataAndRefresh () async {
    try {
      setState(() {
        _isLoading = true;
      });

      final customer = await ServerApi.fetchCustomer(Global.customer_id);
      await Future.delayed(Duration(seconds: 1));
      Global.customer = customer;

      if (mounted == false)
        return;

      setState(() {
        _isLoading = false;
        _profileInfo = _ProfileInfo(
          customer.name        ,
          customer.phone_number,
          customer.email       ,
          customer.address     ,
        );
        _phoneNumberCtr.text = _profileInfo.phoneNumber;
        _emailCtr      .text = _profileInfo.email      ;
        _addressCtr    .text = _profileInfo.address    ;
      });

    }on ServerApiException catch (e) {
      final msg = json.decode(e.response.body)['message'];
      _scaffoldKey.currentState.showSnackBar(
        SnackBar(content: Text(msg)),
      );

      setState(() {
        _isLoading = false;
      });

    }catch (e) {
      _scaffoldKey.currentState.showSnackBar(
        SnackBar(content: Text(e.toString())),
      );

      setState(() {
        _isLoading = false;
      });
    }

  }

}

class _ProfileInfo {
  String name;
  String phoneNumber;
  String email;
  String address;

  _ProfileInfo (this.name, this.phoneNumber, this.email, this.address);
}