import 'dart:async';

import 'package:flutter/material.dart';



class LoadingWrapper extends StatelessWidget {
  bool isLoading;
  Widget child;

  LoadingWrapper({Key key, this.isLoading, this.child}): super(key: key);

  @override
  Widget build(BuildContext context) {

    return Stack(
      children: <Widget>[
        child,

        _LoadingCircle(
          isLoading: isLoading,
        ),

      ],
    );
  }
}

class _LoadingCircle extends StatefulWidget {
  bool isLoading;

  _LoadingCircle ({Key key, this.isLoading}): super(key: key);

  @override
  __LoadingCircleState createState() => __LoadingCircleState();
}

class __LoadingCircleState extends State<_LoadingCircle> with SingleTickerProviderStateMixin {
  AnimationController _animationCtr;
  Animation<double>   _animation;
  bool _isShowing = false;


  @override
  void initState() {
    super.initState();

    _animationCtr = AnimationController(
      duration: Duration(milliseconds: 1000),
      vsync: this,
    );

    _animation = Tween<double>(begin: 0, end: 1).animate(_animationCtr);
    _animation.addListener(() {
      if (mounted == false)
        return;

      setState(() { });
    });
    
    _animationCtr.addStatusListener((status) {
      if (mounted == false)
        return;

      switch (status) {
        case AnimationStatus.forward:
          setState(() { _isShowing = true; });
          break;
        case AnimationStatus.dismissed:
          setState(() { _isShowing = false; });
          break;
        default:
          break;
      }
    });
  }

  @override
  void dispose() {
    _animationCtr.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    if (widget.isLoading != _isShowing) {
      if (widget.isLoading)
        _animationCtr.forward();
      else
        _animationCtr.reverse();
    }


    if (_isShowing == false)
      return SizedBox();

    return Opacity(
      opacity: _animation.value,
      child: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black38,
              ),
              child: Center(
                child: CircularProgressIndicator(
                  valueColor: new AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );

  }
}
