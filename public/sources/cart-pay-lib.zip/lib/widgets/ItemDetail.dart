import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:my_eshop/utils/Global.dart';
import 'package:my_eshop/utils/ServerApi.dart';
import 'package:my_eshop/utils/StringUtil.dart';
import 'package:my_eshop/widgets/LoadingWrapper.dart';


enum ItemDetailResult {
  BACK,
  ADD_TO_CART,
}

class ItemDetail extends StatefulWidget {
  int itemId;

  ItemDetail({Key key, @required this.itemId}): super(key: key);

  @override
  _ItemDetailState createState() => _ItemDetailState();
}

class _ItemDetailState extends State<ItemDetail> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  _ItemInfo _itemInfo;
  final _countController = TextEditingController(text: '1');
  bool _isLoading = false;
  bool _isCarted  = false;

  @override
  void initState() {
    super.initState();

    _itemInfo = _makeItemInfo(widget.itemId);

    _countController.addListener(() {
      // on change
      setState(() {});
    });

    _fetchDataAndRefresh();
  }

  @override
  void dispose() {
    super.dispose();

    _countController.dispose();
  }

  @override
  Widget build(BuildContext context) {

    int count = (_countController.text == '')? 0: int.parse(_countController.text);

    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text(_itemInfo.title),
      ),

      body: LoadingWrapper(
        isLoading: _isLoading,
        child: Column(
          children: <Widget>[
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    // image
                    Container(
                      margin: EdgeInsets.all(30),
                      width: double.infinity,
                      child: _itemInfo.image,
                    ),

                    SizedBox(height: 10.0),  // space

                    // title
                    Text(
                      _itemInfo.title,
                      style: TextStyle(fontSize: 22.0),
                    ),

                    SizedBox(height: 10.0),  // space

                    // description
                    Text(
                      _itemInfo.description,
                      style: TextStyle(fontSize: 15.0, color: Colors.black54),
                    ),

                    SizedBox(height: 10.0),  // space

                    // price
                    Text(
                      '${StringUtil.makeCommaedString(_itemInfo.price)} 원',
                      style: TextStyle(fontSize: 18.0, color: Colors.orange),
                    ),

                    // detail contents
                    Container(
                      padding: EdgeInsets.all(30),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: _itemInfo.detailContents.map<Widget>((content) {
                          return Container(
                            margin: EdgeInsets.only(top: 5),
                            child: Text(content, style: TextStyle(fontSize: 15.0)),
                          );
                        }).toList(),
                      ),
                    ),

                  ],
                ),
              ),
            ),


            // space and border top
            Container(
              height: 10.0,
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(color: Colors.black54),
                ),
              ),
            ),

            // cart
            Container(
              padding: EdgeInsets.only(left: 30, right: 30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(
                    width: 60.0,
                    child: TextField(
                      controller: _countController,
                      keyboardType: TextInputType.numberWithOptions(),
                      inputFormatters: [
                        WhitelistingTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(3),
                      ],
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.all(9),
                      ),
                    ),
                  ),
                  SizedBox(width: 5.0),
                  Text('개', style: TextStyle(fontSize: 16),),
                  Expanded(
                    child: SizedBox(),
                  ),
                  Text(
                    '${_computeTotalPrice()} 원',
                    style: TextStyle(fontSize: 18, color: Colors.orange),
                  ),
                ],
              ),
            ),

            Container(
              width: double.infinity,
              margin: EdgeInsets.fromLTRB(30, 5, 30, 8),
              child: FlatButton(
                color: Colors.blue,
                textColor: Colors.white,
                padding: EdgeInsets.only(top: 10, bottom: 10),
                child: Text((_isCarted)? '이미 장바구니에 있음': '장바구니에 넣기', style: TextStyle(fontSize: 16),),
                onPressed:
                  (count <= 0 || _isCarted)?
                    null:
                    () async {
                      setState(() { _isLoading = true; });

                      try {
                        await ServerApi.createCustomerHasItem(
                            Global.customer_id, widget.itemId, count);
                        if (mounted == false)
                          return;

                        setState(() { _isLoading = false; });
                        Navigator.pop(context, ItemDetailResult.ADD_TO_CART);

                      }on ServerApiException catch (e) {
                        _scaffoldKey.currentState.showSnackBar(
                          SnackBar(content: Text(json.decode(e.response.body)['message'])),
                        );
                        setState(() { _isLoading = false; });
                      }catch (e) {
                        _scaffoldKey.currentState.showSnackBar(
                          SnackBar(content: Text(e.toString())),
                        );
                        setState(() { _isLoading = false; });
                      }

                    },
              ),
            ),

          ],
        ),
      ),
    );
  }

  Future<void> _fetchDataAndRefresh () async {
    setState(() { _isLoading = true; });

    try {
      final chiList = await ServerApi.fetchCustomerHasItem({
        'where': {
          'item_id': widget.itemId,
          'status': 'CART',
        },
        'include': ['item'],
      });

      setState(() {
        _isLoading = false;
        _isCarted  = chiList.length > 0;
      });

    }on ServerApiException catch (e) {
      _scaffoldKey.currentState.showSnackBar(
        SnackBar(content: Text(json.decode(e.response.body)['message'])),
      );
      setState(() { _isLoading = false; });

    }catch (e) {
      _scaffoldKey.currentState.showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
      setState(() { _isLoading = false; });
    }
  }

  String _computeTotalPrice () {
    final count = (_countController.text == '')? 0: int.parse(_countController.text);
    return StringUtil.makeCommaedString(_itemInfo.price * count);
  }

  _ItemInfo _makeItemInfo (int itemId) {
    if (itemId == null)
      return null;

    final item = Global.items.firstWhere((it)=>it.id==itemId);
    if (item == null)
      return null;

    final detailContents = <String>[];
    for (final dc in json.decode(item.detail_contents))
      detailContents.add(dc);

    return _ItemInfo(
      Image.network(item.image),
      item.title,
      item.description,
      item.price,
      detailContents,
    );
  }

}

class _ItemInfo {
  Image        image;
  String       title;
  String       description;
  int          price;
  List<String> detailContents;

  _ItemInfo(this.image, this.title, this.description, this.price, this.detailContents);
}