import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:my_eshop/utils/Global.dart';
import 'package:my_eshop/utils/ServerApi.dart';
import 'package:my_eshop/utils/StringUtil.dart';
import 'package:my_eshop/widgets/ItemDetail.dart';
import 'package:my_eshop/widgets/LoadingWrapper.dart';


class ItemList extends StatefulWidget {
  Function onAddToCart;

  ItemList({Key key, @required this.onAddToCart}): super(key: key);

  @override
  _ItemListState createState() => _ItemListState();
}


class _ItemListState extends State<ItemList> {

  bool _isLoading = false;
  List<_ItemInfo> _item_infos;


  @override
  void initState() {
    super.initState();

    _item_infos = _makeItemInfos(Global.items);
    if (_item_infos.length <= 0)
      _fetchDataAndRefresh();
  }

  @override
  Widget build(BuildContext context) {

    // make widgets
    final widgets = <Widget>[];
    for (final ii in _item_infos) {
      widgets.add(
        FlatButton(
          onPressed: () async {
            final result = await Navigator.push<ItemDetailResult>(
              context,
              MaterialPageRoute(builder: (context)=> ItemDetail(itemId: ii.id)),
            );
            if (result == ItemDetailResult.ADD_TO_CART)
              widget.onAddToCart();
          },
          child: Row(
            children: <Widget>[
              Expanded(
                flex: 2,
                child: Container(
                  height: 150.0,
                  margin: EdgeInsets.only(right: 20.0),
                  child: ii.image,
                ),
              ),
              Flexible(
                flex: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      ii.title,
                      style: TextStyle(fontSize: 18.0),
                    ),
                    Text(
                      ii.description,
                      style: TextStyle(fontSize: 15.0, color: Colors.black54),
                    ),
                    Text(
                      ii.price,
                      style: TextStyle(fontSize: 15.0, color: Colors.orange),
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
      );
    }


    return Scaffold(
      body: LoadingWrapper(
        isLoading: _isLoading,
        child: ListView(
          children: widgets,
        ),
      ),
    );
  }

  void _fetchDataAndRefresh () async {
    try {
      setState(() {
        _isLoading = true;
      });

      final items = await ServerApi.fetchItems({});
      await Future.delayed(Duration(seconds: 2));
      Global.items = items;

      if (this.mounted == false)
        return;

      final new_item_infos = _makeItemInfos(items);

      setState(() {
        _item_infos = new_item_infos;
        _isLoading  = false;
      });

    }on ServerApiException catch (e) {
      final msg = json.decode(e.response.body)['message'];
      print(msg);
      setState(() {
        _isLoading  = false;
      });

    }catch (e) {
      print(e.toString());
      setState(() {
        _isLoading  = false;
      });
    }
  }

  List<_ItemInfo> _makeItemInfos (List<ItemResponse> items) {
    final new_item_infos = <_ItemInfo>[];
    for (final it in items) {
      new_item_infos.add(
        _ItemInfo(
          it.id,
          Image.network(it.image),
          it.title,
          it.description,
          StringUtil.makeCommaedString(it.price) + '원',
        ),
      );
    }

    return new_item_infos;
  }

}

class _ItemInfo {
  int   id;
  Image image;
  String title;
  String description;
  String price;

  _ItemInfo(this.id, this.image, this.title, this.description, this.price);
}