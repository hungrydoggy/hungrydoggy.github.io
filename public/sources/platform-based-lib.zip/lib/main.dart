import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'dart:io';


bool needMaterial = true;

void main() {
  if (Platform.isAndroid)
    needMaterial = true;
  else if (Platform.isIOS)
    needMaterial = false;

  // test
  needMaterial = true;

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return PlatformApp(
      title: 'Flutter Demo',
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return PlatformScaffold(
      title: widget.title,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.display1,
            ),
          ],
        ),
      ),
      floatingActionButton:
        (needMaterial)?
          FloatingActionButton(
            onPressed: _incrementCounter,
            tooltip: 'Increment',
            child: Icon(Icons.add),
          ):
          CupertinoButton(
            onPressed: _incrementCounter,
            child: Icon(CupertinoIcons.add, size: 40),
          ),
    );

  }
}


class PlatformApp extends StatelessWidget {
  String title;
  Widget home;


  PlatformApp ({Key key, this.title, this.home}): super(key: key);

  @override
  Widget build(BuildContext context) {
    if (needMaterial == false) {
      return CupertinoApp(
        title: title,
        theme: CupertinoThemeData(),
        home: home,
      );
    }

    return MaterialApp(
      title: title,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: home,
    );
  }

}


class PlatformScaffold extends StatelessWidget {
  String title;
  Widget body;
  Widget floatingActionButton;


  PlatformScaffold({Key key, this.title, this.body, this.floatingActionButton}): super(key: key);

  @override
  Widget build(BuildContext context) {

    if (needMaterial == false) {
      return CupertinoPageScaffold(
        navigationBar: CupertinoNavigationBar(
          middle: Text(title),
        ),
        child: Stack(
          children: <Widget>[
            body,

            Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.all(10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      floatingActionButton,
                    ],
                  ),
                ),
              ],
            ),

          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: body,
      floatingActionButton: floatingActionButton,
    );
  }

}