import 'package:flutter/material.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/services.dart';
import 'package:my_eshop/widgets/Login.dart';
import 'package:my_eshop/widgets/MainWidget.dart';


void main () {
  final FirebaseMessaging firebaseMessaging = FirebaseMessaging();

  firebaseMessaging.requestNotificationPermissions(
    IosNotificationSettings(sound: true, badge: true, alert: true),
  );

  firebaseMessaging.configure(
    // 앱이 활성화 상태(foreground) 일때
    onMessage: (Map<String, dynamic> message) async {
      print('onMessage: ${message}');
    },
    // 앱이 종료된 상태에서, 노티피케이션을 눌러서 실행될때
    onLaunch: (Map<String, dynamic> message) async {
      print('onLaunch: ${message}');
    },
    // 앱이 비활성화 상태(background) 일때, 노티피케이션을 눌러서 열때
    onResume: (Map<String, dynamic> message) async {
      print('onResume: ${message}');
    },
  );


  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,    // 기본 방향만 가능하게 함
    //DeviceOrientation.portraitDown,
    //DeviceOrientation.landscapeLeft,
    //DeviceOrientation.landscapeRight,
  ]);


  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My eshop',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => Login(),
        '/main': (context) => MainWidget(),
      },
    );
  }
}
