import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:my_eshop/utils/Global.dart';
import 'package:my_eshop/utils/ServerApi.dart';

import 'package:my_eshop/widgets/HttpTest.dart';
import 'package:my_eshop/widgets/LoadingWrapper.dart';
import 'package:my_eshop/widgets/MainWidget.dart';
import 'package:my_eshop/widgets/Register.dart';


class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey     = GlobalKey<FormState    >();

  final _emailCtrl    = TextEditingController(text: 'test@test.com');
  final _passwordCtrl = TextEditingController(text: 'test');

  bool _isLoading = false;


  @override
  void dispose() {
    super.dispose();

    _emailCtrl   .dispose();
    _passwordCtrl.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: LoadingWrapper(
        isLoading: _isLoading,
        child: SafeArea(
          child: Center(
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        'My eShop',
                        style: TextStyle(fontSize: 50.0),
                      ),
                      Container(width: 10.0),
                      Icon(Icons.pets),
                    ],
                  ),

                  Container(height: 30.0),

                  FractionallySizedBox(
                    widthFactor: 0.5,
                    child: TextFormField(
                      controller: _emailCtrl,
                      decoration: InputDecoration(
                        hintText: 'Please enter an email',
                      ),
                      validator: (v)=>(v.isEmpty)? '내용을 입력해 주세요.': null,
                    ),
                  ),

                  FractionallySizedBox(
                    widthFactor: 0.5,
                    child: TextFormField(
                      controller: _passwordCtrl,
                      decoration: InputDecoration(
                        hintText: 'Please enter a password',
                      ),
                      validator: (v)=>(v.isEmpty)? '내용을 입력해 주세요.': null,
                      obscureText: true,
                    ),
                  ),

                  Container(height: 10.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      FlatButton(
                        child: Text('sign in'),
                        onPressed: () async {
                          try {
                            if (_formKey.currentState.validate() == false) {
                              return;
                            }

                            setState(() {
                              _isLoading = true;
                            });

                            final res = await ServerApi.login(
                              _emailCtrl   .text,
                              _passwordCtrl.text,
                            );

                            setState(() {
                              _isLoading = false;
                            });

                            Global.items               = []       ;
                            Global.token               = res.token;
                            Global.customer_id         = res.id   ;
                            Global.oldCustomerHasItems = []       ;
                            Global.customer            = null    ;

                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => MainWidget())
                            );

                          }on ServerApiException catch (e) {
                            _scaffoldKey.currentState.showSnackBar(
                              SnackBar(
                                content: Text('로그인 실패\n${json.decode(e.response.body)['message']}'),
                              ),
                            );
                            setState(() {
                              _isLoading = false;
                            });
                          }catch (e) {
                            _scaffoldKey.currentState.showSnackBar(
                              SnackBar(
                                content: Text('에러\n${e.toString()}'),
                              ),
                            );
                            setState(() {
                              _isLoading = false;
                            });
                          }
                        },
                      ),

                      FlatButton(
                        child: Text('sign up'),
                        onPressed: () async {
                          await Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context)=> Register())
                          );
                        },
                      ),
                    ],
                  ),

                ],
              ),
            ), // end of Column

          ),
        ),
      ),
    );
  }
}