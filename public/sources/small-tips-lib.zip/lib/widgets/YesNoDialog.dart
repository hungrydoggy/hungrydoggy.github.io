import 'package:flutter/material.dart';


class YesNoDialog {

  static Future<bool> show (
      BuildContext context, String title, String content) async {

    return Navigator.push(context, _YesNoDialogRoute(title:title, content:content));
  }
}


class _YesNoDialogRoute extends ModalRoute<bool> {

  String title   = '';
  String content = '';

  _YesNoDialogRoute ({this.title, this.content, RouteSettings settings}): super(settings: settings);

  @override
  // TODO: implement barrierColor
  Color get barrierColor => Colors.black.withOpacity(0.5);

  @override
  // TODO: implement barrierDismissible
  bool get barrierDismissible => true;

  @override
  // TODO: implement barrierLabel
  String get barrierLabel => null;

  @override
  Widget buildPage(BuildContext context, Animation<double> animation, Animation<double> secondaryAnimation) {
    return Center(
      child: FractionallySizedBox(
        widthFactor: 0.8,
        child: SizedBox(
          height: 200,
          child: Material(
            borderRadius: BorderRadius.circular(20),
            child: Container(
              margin: EdgeInsets.fromLTRB(30, 30, 30, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(title, style: TextStyle(fontSize: 20),),
                  SizedBox(height: 30),

                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: <Widget>[
                          Text(content, style: TextStyle(fontSize: 17),),
                        ],
                      ),
                    ),
                  ),

                  SizedBox(height: 10),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: FlatButton(
                          child: Text('예'),
                          onPressed: () {
                            Navigator.pop(context, true);
                          },
                        ),
                      ),
                      Expanded(
                        child: FlatButton(
                          child: Text('아니오'),
                          onPressed: () {
                            Navigator.pop(context, false);
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  // TODO: implement maintainState
  bool get maintainState => false;

  @override
  // TODO: implement opaque
  bool get opaque => false;

  @override
  // TODO: implement transitionDuration
  Duration get transitionDuration => Duration(milliseconds: 300);

}